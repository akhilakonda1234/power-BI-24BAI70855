SPOTIFY 2023 POWER BI MST - HOW TO TURN THIS PROJECT INTO THE .PBIX

This folder is a Power BI Project (.pbip). Power BI Desktop opens it and
can save it as a normal .pbix file.

1. Install/open Power BI Desktop (recent version).
   If .pbip files will not open: File > Options and settings > Options >
   Preview features > tick "Power BI Project (.pbip) save option", restart.
2. Double-click  Spotify_2023_Data_Analysis_MST.pbip
   (If asked to upgrade/convert the report format, accept.)
3. Click Home > Refresh. The data is embedded, so no file path is needed.
   Wait until all 6 pages show data.
4. Check each page (see checklist below). Fix anything that looks wrong.
5. File > Save as > choose  Spotify_2023_Data_Analysis_MST.pbix
6. File > Export > Export to PDF  ->  Spotify_2023_PowerBI_Report.pdf
7. Make folder Spotify_2023_MST_Submission containing:
     Spotify_2023_Data_Analysis_MST.pbix
     Spotify_2023_PowerBI_Report.pdf
     spotify-2023.csv
   Right-click > Send to > Compressed (zipped) folder.

CHECKLIST
- Transform data: table "spotify-2023", 952 valid streams (1 null), 24 columns
- Model: 15 measures + calculated column "BPM Range" (sorted by hidden "BPM Range Order")
- Pages: 01 Platform Comparison, 02 Artist Impact, 03 Playlist & Chart
  Performance, 04 Shazam Discovery, 05 Major vs Minor, 06 BPM & Song Performance
- Page 2 bar charts: if Top 10 filter is missing, add it in Filters pane
  (artist(s)_name > Top N > 10 > by Total Streams / Spotify Playlist Exposure)
- Each page: navigator on top, slicers under it, titles on every visual
